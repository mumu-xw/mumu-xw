const express = require('express');
const axios = require('axios');
const bodyParser = require('body-parser');
const path = require('path');

const app = express();
app.use(bodyParser.json());

const clientId = 'w6ZuXZy8iyjLDZkRbPachmvh';
const clientSecret = 'yeCAzFlY03YtXWxGHVryIk6f2YTR6VBT';
let accessToken = '';

async function getAccessToken() {
    try {
        const response = await axios.post(
            'https://aip.baidubce.com/oauth/2.0/token',
            null,
            {
                params: {
                    grant_type: 'client_credentials',
                    client_id: clientId,
                    client_secret: clientSecret,
                },
            }
        );
        accessToken = response.data.access_token;
    } catch (error) {
        console.error('Error fetching access token:', error);
    }
}

// 初始化获取 Access Token
getAccessToken();

// 每隔一段时间刷新 Access Token
setInterval(getAccessToken, 24 * 60 * 60 * 1000); // 每24小时刷新一次

// 静态文件处理
app.use(express.static(path.join(__dirname)));

app.post('/ask', async (req, res) => {
    const question = req.body.question;

    // 特定问题的预设回答
    const predefinedAnswers = {
        '你是谁': '我是呱呱聊天助手。',
        '你叫什么名字': '我叫呱呱',
    };

    if (predefinedAnswers[question]) {
        return res.json({ answer: predefinedAnswers[question] });
    }

    try {
        const apiResponse = await axios.post(
            `https://aip.baidubce.com/rpc/2.0/ai_custom/v1/wenxinworkshop/chat/eb-instant?access_token=${accessToken}`,
            {
                messages: [
                    { role: 'user', content: question }
                ]
            },
            {
                headers: {
                    'Content-Type': 'application/json',
                },
            }
        );

        const aiResponse = apiResponse.data;
        if (aiResponse.result) {
            res.json({ answer: aiResponse.result });
        } else {
            res.status(500).json({ error: 'AI response error', details: aiResponse });
        }
    } catch (error) {
        console.error('Error processing question:', error);
        res.status(500).json({ error: 'Error processing question', details: error.message });
    }
});

app.listen(3000, () => {
    console.log('Server is running on http://localhost:3000');
});
